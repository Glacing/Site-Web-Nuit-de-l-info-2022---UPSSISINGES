<!DOCTYPE HTML>
<html>
 <head>
  <meta charset="utf-8"/>
  <title>Liste des témoignages</title>
  <link rel="stylesheet" href="style.css">
 </head>
 <body class="back">
    <header>
        <nav class="nav-bar"> 
            <a href="#" class="logo">Jeu dépiste.</a>
            <div class="nav-links">
                <ul>
                    <li><a href="index.html">Home</a></li>
                    <li><a href="formulaire.html">Formulaire</a></li>
                    <li><a href="jeux.html">Jeux</a></li>
                    <li><a href="notre_equipe.html">Notre équipe</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="temoignages.php">Témoignages</a></li>
                </ul>
            </div>
        </nav>
    </header>

<div class="bloc_php">
  <h3><p>Un témoignage peut parfois en aider plus d'un...</p></h3>
</div>
<div class="bloc_php">
<?php
echo('<br>');

$servername = "mysql-jeudepiste.alwaysdata.net";
$username = "291431_root";
$password = "UPSSISINGES2022";

try {
	$conn = new PDO("mysql:host=$servername;dbname=jeudepiste_data", $username, $password);
	$conn->exec("set names utf8");
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $getTemoignages = $conn->prepare("SELECT * FROM temoignages");
  $getTemoignages->execute();
  $temoignages = $getTemoignages->fetchAll();
  echo"<table border='1'>";
  echo"<tr><td>Témoignages récents</td></tr>\n";

  foreach ($temoignages as $temoignages) {
    echo"<tr><td>{$temoignages['valeur']}</td></tr>\n";
  }
  echo"</table>";
} catch(PDOException $e) {
}
$conn = null;

?>
</div>
</body>
</html>